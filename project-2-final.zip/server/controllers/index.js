module.exports.Account = require('./Account.js');
module.exports.Tweet = require('./Tweet.js');

module.exports.get404 = (req, res) => res.render('404');
